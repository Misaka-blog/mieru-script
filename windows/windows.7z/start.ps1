./mieru apply config client_config.json
./mieru start